import React from "react";
import { useParams, Link } from "react-router-dom";

const posts = [
  { id: 1, userId: 1, title: "React Basics", content: "Content A" },
  { id: 2, userId: 1, title: "Hooks Guide", content: "Content B" },
  { id: 3, userId: 2, title: "NodeJS Intro", content: "Content C" }
];

function UserDetails() {
  const { id } = useParams();
  const userPosts = posts.filter(p => p.userId === id);

  return (
    <div>
      <h2>User ID: {id}</h2>
      {userPosts.length === 0 ? (
        <p>No posts found for this user</p>
      ) : (
        <ul>
          {userPosts.map(p => (
            <li key={p.id}>
              <Link to={`/users/${id}/posts/${p.id}`}>{p.title}</Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default UserDetails;
