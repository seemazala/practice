import React from "react";
import { Link } from "react-router-dom";

const users = [
  { id: 1, name: "Seema" },
  { id: 2, name: "Ashish" }
];

function Users() {
  return (
    <div>
      <h2>Users List</h2>
      {users.map(u => (
        <div key={u.id}>
          <Link to={`/users/${u.id}`}>{u.name}</Link>
        </div>
      ))}
    </div>
  );
}

export default Users;
