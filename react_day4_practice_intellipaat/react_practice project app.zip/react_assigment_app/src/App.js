import React from 'react';
import './App.css';

function App() {
const Employees = [
  {id : 1, name: "seema", department: "tech", position: "Full stack developer"},
  {id : 2, name: "ashish", department: "HR", position: "HR Manager"},
  {id : 3, name: "prisha", department: "Finance", position: "Accountant"},
  {id : 4, name: "dwira", department : "tech", position: "software Engineer"},
  {id : 5, name: "krishita", department: "tech", position : "AI Engineer"},
];
const techEmployees = Employees.filter((emp) => emp.department === "tech");
return(
  <div className="container">
    <h1>Employees Directory</h1>

    <div className='section'>
      <h2>All Employees</h2>

    <div className='employee-list'>
      {Employees.map((emp) =>(
        <div key={emp.id} className='card'>
          <h3>{emp.name}</h3>
          <p>department : {emp.department}</p>
          <p>position : {emp.position}</p>
        </div>
      ))}
    </div>
    </div>

    <div className='section'>
      <h2>Tech Department Employees</h2>
      <div className='employee-list'>
        {techEmployees.map((emp) => (
          <div key={emp.id} className='card tech'>
            <h3>{emp.name}</h3>
            <p>department: {emp.department}</p>
            <p>position: {emp.position}</p>
          </div>
        ))}
      </div>
    </div>
  </div>
);
}

export default App;
